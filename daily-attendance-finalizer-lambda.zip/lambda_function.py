import json
import boto3
import os
from datetime import datetime

# -----------------------------
# ENV VARIABLES
# -----------------------------

ATTENDANCE_TABLE = os.environ['ATTENDANCE_TABLE']
EMPLOYEES_TABLE = os.environ['EMPLOYEES_TABLE']
REPORTS_TABLE = os.environ['REPORTS_TABLE']

# -----------------------------
# AWS
# -----------------------------

dynamodb = boto3.resource('dynamodb')

attendance_table = dynamodb.Table(ATTENDANCE_TABLE)
employees_table = dynamodb.Table(EMPLOYEES_TABLE)
reports_table = dynamodb.Table(REPORTS_TABLE)

# -----------------------------
# MAIN FUNCTION
# -----------------------------

def lambda_handler(event, context):

    today = datetime.now().strftime("%Y-%m-%d")

    print(f"Running finalizer for {today}")

    # -------------------------
    # FETCH DATA
    # -------------------------

    employees = employees_table.scan().get("Items", [])
    attendance = attendance_table.scan().get("Items", [])

    present_ids = set()
    late_count = 0
    present_count = 0

    # -------------------------
    # PROCESS ATTENDANCE
    # -------------------------

    for record in attendance:

        if record.get("date") == today:

            emp_id = record.get("employee_id")
            present_ids.add(emp_id)

            status = record.get("status", "").lower()

            if status == "present":
                present_count += 1
            elif status == "late":
                late_count += 1

    # -------------------------
    # MARK ABSENTEES
    # -------------------------

    absent_count = 0

    for emp in employees:

        emp_id = emp["employee_id"]

        if emp_id not in present_ids:

            absent_count += 1

            attendance_table.put_item(
                Item={
                    "employee_id": emp_id,
                    "date": today,
                    "status": "absent",
                    "clock_in": "-",
                    "clock_out": "-",
                    "confidence": 0
                }
            )

    # -------------------------
    # CREATE REPORT
    # -------------------------

    report = {
        "date": today,
        "present": present_count,
        "late": late_count,
        "absent": absent_count,
        "total_employees": len(employees),
        "generated_at": datetime.now().isoformat()
    }

    reports_table.put_item(Item=report)

    print("Report generated:", report)

    return {
        "statusCode": 200,
        "body": json.dumps(report)
    }