import boto3
from botocore.config import Config
import os
import uuid
import json

# ✅ FIXED S3 CLIENT (THIS IS THE IMPORTANT PART)
s3 = boto3.client(
    "s3",
    region_name="ap-south-1",
    config=Config(
        signature_version="s3v4",
        s3={"addressing_style": "virtual"}
    )
)

# Bucket from environment variable
BUCKET = os.environ["UPLOAD_BUCKET"]

def lambda_handler(event, context):

    # Generate unique file name
    file_id = str(uuid.uuid4())
    image_key = f"attendance/uploads/{file_id}.jpg"

    # Generate presigned URL (MUST match Content-Type in frontend)
    upload_url = s3.generate_presigned_url(
        ClientMethod="put_object",
        Params={
            "Bucket": BUCKET,
            "Key": image_key,
            "ContentType": "image/jpeg"
        },
        ExpiresIn=300
    )

    # Response
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "GET,OPTIONS"
        },
        "body": json.dumps({
            "uploadUrl": upload_url,
            "imageKey": image_key,
            "imageUrl": f"https://{BUCKET}.s3.ap-south-1.amazonaws.com/{image_key}"
        })
    }