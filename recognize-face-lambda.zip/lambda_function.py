import urllib.parse
import json
import boto3
import os
from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

rekognition = boto3.client("rekognition")
dynamodb = boto3.resource("dynamodb")
s3 = boto3.client("s3")

attendance_table = dynamodb.Table(os.environ["ATTENDANCE_TABLE"])
employee_table = dynamodb.Table(os.environ["EMPLOYEE_TABLE"])

COLLECTION_ID = os.environ["COLLECTION_ID"]
CONFIDENCE_THRESHOLD = 95


def move_image(bucket, source_key, destination_key):
    s3.copy_object(
        Bucket=bucket,
        CopySource={"Bucket": bucket, "Key": source_key},
        Key=destination_key
    )

    s3.delete_object(Bucket=bucket, Key=source_key)

    print(f"Moved image to: {destination_key}")


def lambda_handler(event, context):

    try:
        print("EVENT:", json.dumps(event))

        if "Records" not in event:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid trigger"})
            }

        record = event["Records"][0]
        bucket = record["s3"]["bucket"]["name"]

        key = urllib.parse.unquote_plus(
            record["s3"]["object"]["key"]
        )

        print(f"Processing image: {key}")

        face_check = rekognition.detect_faces(
            Image={"S3Object": {"Bucket": bucket, "Name": key}}
        )

        face_count = len(face_check["FaceDetails"])
        print(f"Faces detected: {face_count}")

        if face_count == 0 or face_count > 1:
            failed_key = key.replace(
                "attendance/uploads/",
                "attendance/failed/"
            )

            move_image(bucket, key, failed_key)

            return {
                "statusCode": 400,
                "body": "Invalid face count"
            }

        response = rekognition.search_faces_by_image(
            CollectionId=COLLECTION_ID,
            Image={"S3Object": {"Bucket": bucket, "Name": key}},
            FaceMatchThreshold=CONFIDENCE_THRESHOLD,
            MaxFaces=1
        )

        matches = response.get("FaceMatches", [])

        if not matches:
            unknown_key = key.replace(
                "attendance/uploads/",
                "attendance/unknown/"
            )
            move_image(bucket, key, unknown_key)

            return {
                "statusCode": 404,
                "body": "No match found"
            }

        best_match = matches[0]
        similarity = float(best_match["Similarity"])

        if similarity < 90:
            unknown_key = key.replace(
                "attendance/uploads/",
                "attendance/unknown/"
            )
            move_image(bucket, key, unknown_key)

            return {
                "statusCode": 404,
                "body": "Low confidence"
            }

        employee_id = best_match["Face"]["ExternalImageId"]

        emp = employee_table.get_item(
            Key={"employee_id": employee_id}
        )

        employee_name = emp.get("Item", {}).get("name", "Unknown Employee")

        print(f"Employee identified: {employee_id} - {employee_name}")

        now = datetime.now(ZoneInfo("Asia/Kolkata"))
        current_date = now.strftime("%Y-%m-%d")
        current_time = now.strftime("%H:%M:%S")

        print("WRITING TO DYNAMODB:", {
            "employee_id": employee_id,
            "date": current_date,
            "time": current_time
        })

        existing = attendance_table.get_item(
            Key={
                "employee_id": employee_id,
                "date": current_date
            }
        )

        # =========================
        # CLOCK IN
        # =========================
        if "Item" not in existing:

            db_response = attendance_table.put_item(
                Item={
                    "employee_id": employee_id,
                    "date": current_date,
                    "clock_in": current_time,
                    "status": "Present",
                    "confidence": Decimal(str(round(similarity, 2)))
                }
            )

            print("DYNAMODB PUT RESPONSE:", db_response)

            processed_key = key.replace(
                "attendance/uploads/",
                "attendance/processed/"
            )

            move_image(bucket, key, processed_key)

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "employee_id": employee_id,
                    "name": employee_name,
                    "status": "Clocked In",
                    "confidence": round(similarity, 2),
                    "time": current_time
                })
            }

        # =========================
        # CLOCK OUT
        # =========================
        item = existing["Item"]

        if "clock_out" not in item:

            db_response = attendance_table.update_item(
                Key={
                    "employee_id": employee_id,
                    "date": current_date
                },
                UpdateExpression="SET clock_out = :c",
                ExpressionAttributeValues={
                    ":c": current_time
                }
            )

            print("DYNAMODB UPDATE RESPONSE:", db_response)

            processed_key = key.replace(
                "attendance/uploads/",
                "attendance/processed/"
            )

            move_image(bucket, key, processed_key)

            return {
                "statusCode": 200,
                "body": json.dumps({
                    "employee_id": employee_id,
                    "name": employee_name,
                    "status": "Clocked Out",
                    "confidence": round(similarity, 2),
                    "time": current_time
                })
            }

        processed_key = key.replace(
            "attendance/uploads/",
            "attendance/processed/"
        )

        move_image(bucket, key, processed_key)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "employee_id": employee_id,
                "name": employee_name,
                "status": "Already Marked",
                "confidence": round(similarity, 2),
                "time": current_time
            })
        }

    except Exception as e:
        print("ERROR:", str(e))

        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }