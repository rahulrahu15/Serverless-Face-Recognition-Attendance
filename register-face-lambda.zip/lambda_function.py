import json
import boto3
import os
from botocore.exceptions import ClientError

rekognition = boto3.client("rekognition")
dynamodb = boto3.resource("dynamodb")

EMPLOYEE_TABLE = os.environ["EMPLOYEE_TABLE"]
COLLECTION_ID = os.environ["COLLECTION_ID"]

table = dynamodb.Table(EMPLOYEE_TABLE)


def create_collection():
    try:
        rekognition.create_collection(
            CollectionId=COLLECTION_ID
        )
        print(f"Collection {COLLECTION_ID} created")

    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceAlreadyExistsException':
            print("Collection already exists")
        else:
            raise e


def lambda_handler(event, context):

    create_collection()

    try:

        bucket = event["Records"][0]["s3"]["bucket"]["name"]
        key = event["Records"][0]["s3"]["object"]["key"]

        print(f"Bucket: {bucket}")
        print(f"Object Key: {key}")

        filename = key.split("/")[-1]

        parts = filename.split("_")

        if len(parts) < 2:
            return {
                "statusCode": 400,
                "body": json.dumps("Invalid filename format. Use EMP001_Rahul.jpg")
            }

        employee_id = parts[0]
        employee_name = parts[1].split(".")[0]

        print(f"Employee ID: {employee_id}")
        print(f"Employee Name: {employee_name}")

        response = rekognition.index_faces(
            CollectionId=COLLECTION_ID,
            Image={
                "S3Object": {
                    "Bucket": bucket,
                    "Name": key
                }
            },
            ExternalImageId=employee_id,
            DetectionAttributes=[]
        )

        print("Rekognition Response:", response)

        if len(response["FaceRecords"]) == 0:
            return {
                "statusCode": 400,
                "body": json.dumps("No face detected in image")
            }

        face_id = response["FaceRecords"][0]["Face"]["FaceId"]

        print(f"Face ID: {face_id}")

        # =====================================================
        # 🔥 FIX ADDED: ENSURE CONSISTENT EMPLOYEE LOOKUP FIELD
        # =====================================================
        table.put_item(
            Item={
                "employee_id": employee_id,
                "name": employee_name,
                "rekognition_face_id": face_id,

                # 🔥 ADDED SAFETY FIELD (important for recognition stage)
                "external_image_id": employee_id
            }
        )

        print("Employee stored in DynamoDB successfully")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Face registered successfully",
                "employee_id": employee_id,
                "employee_name": employee_name,
                "face_id": face_id
            })
        }

    except Exception as e:

        print("ERROR:", str(e))

        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }