import json
import os
import boto3

from boto3.dynamodb.conditions import Key
from decimal import Decimal
from datetime import datetime

# =========================================================
# ENVIRONMENT VARIABLES
# =========================================================

ATTENDANCE_TABLE = os.environ['ATTENDANCE_TABLE']
EMPLOYEES_TABLE = os.environ['EMPLOYEES_TABLE']

# =========================================================
# AWS RESOURCES
# =========================================================

dynamodb = boto3.resource('dynamodb')

attendance_table = dynamodb.Table(ATTENDANCE_TABLE)
employees_table = dynamodb.Table(EMPLOYEES_TABLE)

# =========================================================
# JSON ENCODER
# =========================================================

class DecimalEncoder(json.JSONEncoder):

    def default(self, obj):

        if isinstance(obj, Decimal):
            return float(obj)

        return super(DecimalEncoder, self).default(obj)

# =========================================================
# RESPONSE HELPER
# =========================================================

def response(status_code, body):

    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Allow-Methods": "GET,OPTIONS"
        },
        "body": json.dumps(body, cls=DecimalEncoder)
    }

# =========================================================
# GET ALL ATTENDANCE
# =========================================================

def get_all_attendance(event):

    params = event.get("queryStringParameters") or {}

    limit = int(params.get("limit", 20))

    scan_kwargs = {
        "Limit": limit
    }

    result = attendance_table.scan(**scan_kwargs)

    items = result.get("Items", [])

    # =====================================================
    # ADD EMPLOYEE NAME TO EACH ATTENDANCE RECORD
    # =====================================================

    for item in items:

        emp = employees_table.get_item(
            Key={
                "employee_id": item["employee_id"]
            }
        )

        employee = emp.get("Item", {})

        item["name"] = employee.get(
            "name",
            "Unknown Employee"
        )

    return response(200, {
        "count": len(items),
        "records": items
    })

# =========================================================
# GET SINGLE EMPLOYEE ATTENDANCE
# =========================================================

def get_employee_attendance(employee_id):

    result = attendance_table.query(
        KeyConditionExpression=Key('employee_id').eq(employee_id)
    )

    items = result.get("Items", [])

    return response(200, {
        "employee_id": employee_id,
        "count": len(items),
        "records": items
    })

# =========================================================
# GET ALL EMPLOYEES
# =========================================================

def get_employees():

    result = employees_table.scan()

    items = result.get("Items", [])

    return response(200, {
        "count": len(items),
        "employees": items
    })

# =========================================================
# DAILY REPORT
# =========================================================

def get_daily_report():

    today = datetime.now().strftime("%Y-%m-%d")

    attendance_result = attendance_table.scan()

    attendance_items = attendance_result.get("Items", [])

    employee_result = employees_table.scan()

    employee_items = employee_result.get("Items", [])

    total_employees = len(employee_items)

    present_ids = set()

    present = 0
    late = 0

    for item in attendance_items:

        if item.get("date") == today:

            present_ids.add(item.get("employee_id"))

            status = item.get("status", "").lower()

            if status == "present":
                present += 1

            elif status == "late":
                late += 1

    absent = total_employees - len(present_ids)

    return response(200, {
        "date": today,
        "present": present,
        "late": late,
        "absent": absent,
        "total_employees": total_employees
    })
# =========================================================
# WEEKLY REPORT
# =========================================================

def get_weekly_report():

    today = datetime.now()

    week_start = today - timedelta(days=6)

    attendance_result = attendance_table.scan()

    attendance_items = attendance_result.get("Items", [])

    present = 0
    late = 0
    absent = 0

    total_records = 0

    for item in attendance_items:

        item_date = item.get("date")

        if not item_date:
            continue

        try:

            record_date = datetime.strptime(
                item_date,
                "%Y-%m-%d"
            )

            if week_start.date() <= record_date.date() <= today.date():

                total_records += 1

                status = item.get(
                    "status",
                    ""
                ).lower()

                if status == "present":
                    present += 1

                elif status == "late":
                    late += 1

                elif status == "absent":
                    absent += 1

        except Exception:
            continue

    present_percentage = 0
    late_percentage = 0
    absent_percentage = 0

    if total_records > 0:

        present_percentage = round(
            (present / total_records) * 100,
            2
        )

        late_percentage = round(
            (late / total_records) * 100,
            2
        )

        absent_percentage = round(
            (absent / total_records) * 100,
            2
        )

    return response(200, {

        "week_start": week_start.strftime("%Y-%m-%d"),

        "week_end": today.strftime("%Y-%m-%d"),

        "total_records": total_records,

        "present": present,

        "late": late,

        "absent": absent,

        "present_percentage": present_percentage,

        "late_percentage": late_percentage,

        "absent_percentage": absent_percentage
    })

# =========================================================
# MAIN LAMBDA ROUTER (HTTP API VERSION)
# =========================================================

def lambda_handler(event, context):

    print("EVENT:")
    print(json.dumps(event))

    try:

        # -------------------------------------------------
        # HTTP API DETAILS
        # -------------------------------------------------

        method = event["requestContext"]["http"]["method"]

        path = event["rawPath"]

        print("METHOD:", method)
        print("PATH:", path)

        # -------------------------------------------------
        # GET /attendance
        # -------------------------------------------------

        if path == "/attendance" and method == "GET":

            return get_all_attendance(event)

        # -------------------------------------------------
        # GET /attendance/{employee_id}
        # -------------------------------------------------

        elif path.startswith("/attendance/") and method == "GET":

            employee_id = path.split("/")[-1]

            return get_employee_attendance(employee_id)

        # -------------------------------------------------
        # GET /employees
        # -------------------------------------------------

        elif path == "/employees" and method == "GET":

            return get_employees()

        # -------------------------------------------------
        # GET /reports/daily
        # -------------------------------------------------

        elif path == "/reports/daily" and method == "GET":

            return get_daily_report()
        # -------------------------------------------------
        # GET /reports/weekly
        # -------------------------------------------------

        elif path == "/reports/weekly" and method == "GET":

            return get_weekly_report()

        # -------------------------------------------------
        # ROUTE NOT FOUND
        # -------------------------------------------------

        return response(404, {
            "message": "Route not found"
        })

    except Exception as e:

        print("ERROR:")
        print(str(e))

        return response(500, {
            "error": str(e)
        })